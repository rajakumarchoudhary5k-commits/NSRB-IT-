/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */
import { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Send, User, Trash2 } from 'lucide-react';

type Message = { id: number; sender: 'user' | 'ai'; text: string; timestamp: string };

export default function App() {
  const [messages, setMessages] = useState<Message[]>(() => {
    const saved = localStorage.getItem('nexora_chat_history');
    return saved ? JSON.parse(saved) : [{ id: 1, sender: 'ai', text: 'Namaste! ⚡️ I am Nexora AI, the most advanced intelligence ever built in India by Raja Kumar Choudhary. How can I help you evolve today?', timestamp: new Date().toLocaleTimeString() }];
  });
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const resetChat = () => {
    localStorage.removeItem('nexora_chat_history');
    setMessages([{ id: 1, sender: 'ai', text: 'Namaste! ⚡️ I am Nexora AI, the most advanced intelligence ever built in India by Raja Kumar Choudhary. How can I help you evolve today?', timestamp: new Date().toLocaleTimeString() }]);
  };

  useEffect(scrollToBottom, [messages]);

  useEffect(() => {
    localStorage.setItem('nexora_chat_history', JSON.stringify(messages));
  }, [messages]);

  const sendMessage = async () => {
    if (!input.trim()) return;
    const now = new Date().toLocaleTimeString();
    const userMessage: Message = { id: Date.now(), sender: 'user', text: input, timestamp: now };
    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setLoading(true);

    try {
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message: input, userId: 'user123' }),
      });
      const data = await response.json();
      setMessages(prev => [...prev, { id: Date.now() + 1, sender: 'ai', text: data.reply, timestamp: new Date().toLocaleTimeString() }]);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex flex-col h-screen bg-neutral-950 text-neutral-100 font-sans">
      <header className="p-6 border-b border-neutral-800 flex items-center justify-between">
        <h1 className="text-2xl font-bold tracking-tight text-transparent bg-clip-text bg-linear-to-r from-cyan-400 to-purple-600">Nexora AI</h1>
        <div className="flex items-center gap-4">
          <button onClick={resetChat} className="text-neutral-500 hover:text-red-400 transition" title="Clear chat">
             <Trash2 className="w-6 h-6" />
          </button>
          <img src="/src/assets/images/infinity_icon_1780811643197.png" alt="Nexora Infinity" className="w-6 h-6" />
        </div>
      </header>
      
      <main className="flex-1 overflow-y-auto p-6 space-y-4">
        <AnimatePresence>
          {messages.map(m => (
            <motion.div 
              key={m.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className={`flex gap-3 ${m.sender === 'user' ? 'justify-end' : ''}`}
            >
              {m.sender === 'ai' && <img src="/src/assets/images/infinity_icon_1780811643197.png" alt="Nexora" className="w-6 h-6 mt-1" />}
              <div className="flex flex-col gap-1">
                <div className={`p-4 rounded-2xl max-w-lg ${m.sender === 'user' ? 'bg-purple-600 text-white' : 'bg-neutral-800'}`}>
                  {m.text}
                </div>
                <span className="text-[10px] text-neutral-600 px-2">{m.timestamp}</span>
              </div>
              {m.sender === 'user' && <User className="text-purple-400 mt-1" />}
            </motion.div>
          ))}
          {loading && (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="flex gap-1 p-4 rounded-2xl bg-neutral-800 w-fit">
              <motion.div className="w-2 h-2 rounded-full bg-neutral-500" animate={{ scale: [1, 1.5, 1] }} transition={{ repeat: Infinity, duration: 1, delay: 0 }} />
              <motion.div className="w-2 h-2 rounded-full bg-neutral-500" animate={{ scale: [1, 1.5, 1] }} transition={{ repeat: Infinity, duration: 1, delay: 0.2 }} />
              <motion.div className="w-2 h-2 rounded-full bg-neutral-500" animate={{ scale: [1, 1.5, 1] }} transition={{ repeat: Infinity, duration: 1, delay: 0.4 }} />
            </motion.div>
          )}
        </AnimatePresence>
        <div ref={messagesEndRef} />
      </main>

      <footer className="p-4 border-t border-neutral-800 flex gap-2">
        <input 
          className="flex-1 bg-neutral-900 border border-neutral-700 rounded-full px-6 py-3 focus:outline-hidden focus:ring-2 focus:ring-purple-500"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && sendMessage()}
          placeholder="Ask Nexora anything..."
        />
        <button onClick={sendMessage} className="bg-purple-600 p-3 rounded-full hover:bg-purple-700 transition">
          <Send className="w-5 h-5 text-white" />
        </button>
      </footer>
    </div>
  );
}
